package com.beriii.noteapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private EditText loginEmailTxt, loginPassTxt;
    private RelativeLayout login, signupBtn;
    private TextView forgotBtn;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

//        getSupportActionBar().hide();

        loginEmailTxt = findViewById(R.id.loginEmailTxt);
        loginPassTxt = findViewById(R.id.loginPassTxt);
        login = findViewById(R.id.login);
        signupBtn = findViewById(R.id.signupBtn);
        forgotBtn = findViewById(R.id.forgotBtn);

        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();

        if(firebaseUser != null){
            finish();
            startActivity(new Intent(MainActivity.this, notesActivity.class));
        }

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, signup.class));
            }
        });

        forgotBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, forgotPassword.class));
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = loginEmailTxt.getText().toString().trim();
                String pass = loginPassTxt.getText().toString().trim();

                if(email.isEmpty() || pass.isEmpty()){
                    Toast.makeText(getApplicationContext(), "All field are required!", Toast.LENGTH_SHORT).show();
                }else{
                    //login user

                    firebaseAuth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful()){
                                checkEmailVerification();
                            }else{
                                Exception exception = task.getException();

                                if(exception instanceof FirebaseAuthInvalidUserException){
                                    //user not found
                                    Toast.makeText(getApplicationContext(), "Account does not exists!", Toast.LENGTH_SHORT).show();
                                }else if(exception instanceof FirebaseAuthInvalidCredentialsException){
                                    //if pass is incorrect
                                    Toast.makeText(getApplicationContext(), "Invalid Email or Password!", Toast.LENGTH_SHORT).show();
                                }else{
                                    Toast.makeText(getApplicationContext(), "Login failed: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }

                        }
                    });


                }

            }
        });



    }
    private void checkEmailVerification(){
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();

        if(firebaseUser.isEmailVerified()==true){
            Toast.makeText(getApplicationContext(), "Logged in!", Toast.LENGTH_SHORT).show();
            finish();
            startActivity(new Intent(MainActivity.this, notesActivity.class));
        }else{
            Toast.makeText(getApplicationContext(), "Please verify your account!", Toast.LENGTH_SHORT).show();
            firebaseAuth.signOut();
        }
    }
}